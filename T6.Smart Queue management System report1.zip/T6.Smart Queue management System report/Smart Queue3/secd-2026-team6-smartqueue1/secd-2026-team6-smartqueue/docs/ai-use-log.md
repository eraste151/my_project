# AI use log – Team T6

## Entry 1
- **Date:** 7 November 2026
- **Student:** [name]
- **Tool:** Claude
- **What I asked:** To prepare the Session 1 (milestone 1) report for the Smart Queue Management System following the course guide, to check it against the Session 1 checklist, and to prepare sources.md and diagram images.
- **What it produced:** A report with placeholders for interviews, a sources list, a stakeholder map image, and an affinity map template.
- **What I kept, changed, or rejected, and why:** [fill in: for example, which wording was changed, and that interview records were left blank because they must come from real users]
- **How I checked it was correct:** The facts used from sources S1 to S5 were checked against the pages on 7 November 2026. [add what the team checked after: full papers, competitor pages, vendor pricing]
