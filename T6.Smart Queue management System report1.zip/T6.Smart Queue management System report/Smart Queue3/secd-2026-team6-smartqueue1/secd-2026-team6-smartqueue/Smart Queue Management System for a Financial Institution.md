# Smart Queue Management System (SQMS)

**Team:** T6
**Members and roles:**

| Member | Role |
|---|---|
| Jeavis | Project Manager / Scrum Master; Business / Requirements Analyst |
| Eraste | Lead User Researcher; QA and Documentation Lead |
| Janvier | UX / UI Designer; Technical Lead |

**Problem statement (one sentence):** Customers of banks and other financial institutions in Rwanda struggle to use their time well while waiting because they cannot see their queue position or estimated wait, which causes long waits at peak times and stress for staff.

**Project summary:** a customer enters a mobile phone number on a smart queue device, receives a sequential queue number and an estimated waiting time by SMS, and is told by SMS when to go to the counter. Elderly, pregnant, and disabled customers get priority numbers.

## Folder structure
- `docs/m1-discovery/` problem statement, interviews, stakeholder map, affinity map, personas
- `docs/research/` `sources.md`
- `docs/ai-use-log.md` how AI tools were used
- `src/` application code (from Session 4)
- `tests/` automated tests (from Session 5)

## How to run
To be added in Session 4.
